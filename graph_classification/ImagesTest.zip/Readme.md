# Project readme

## Activate/deactivate virtual environment
### Bash
. env/Scripts/activate  
deactivate  

### Powershell
.\env\Scripts\activate  
deactivate  